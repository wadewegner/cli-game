from .game import main

def run_game():
    import curses
    return curses.wrapper(main)

__version__ = "0.1.0"

