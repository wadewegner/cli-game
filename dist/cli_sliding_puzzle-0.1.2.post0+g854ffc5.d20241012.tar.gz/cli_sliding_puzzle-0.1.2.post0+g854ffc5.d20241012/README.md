# CLI Sliding Puzzle Game

A command-line interface sliding puzzle game built with Python.

## Installation

To install the game, you need Python 3.7 or higher and pip. Then run:

pip install cli-sliding-puzzle

## Playing the Game

After installation, run the game by typing:

sliding-puzzle

Use arrow keys to move tiles. Press 'q' to quit.

## Development

### Setup

1. Clone the repository:
   git clone https://github.com/yourusername/cli-sliding-puzzle.git
   cd cli-sliding-puzzle

2. Create a virtual environment:
   python -m venv venv
   source venv/bin/activate  # On Windows, use `venv\Scripts\activate`

3. Install development dependencies:
   pip install build twine setuptools_scm

### Building and Publishing

1. Ensure all changes are committed to git.

2. Create a new git tag for the version:
   git tag -a v0.1.2 -m "Release version 0.1.2"
   git push origin v0.1.2

3. Build the package:
   python -m build

4. Test the package locally:
   pip install dist/cli_sliding_puzzle-0.1.2-py3-none-any.whl

5. Upload to TestPyPI:
   twine upload --repository testpypi dist/*

6. Test installation from TestPyPI:
   pip install --index-url https://test.pypi.org/simple/ --no-deps cli-sliding-puzzle

7. If everything works, upload to PyPI:
   twine upload dist/*

## License

This project is licensed under the MIT License.
