from .game import main as run_game

__version__ = "0.1.0"

